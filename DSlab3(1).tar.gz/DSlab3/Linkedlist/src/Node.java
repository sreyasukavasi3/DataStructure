
public class Node {

	
	      public double dData;                // data item
	      public Node next;                   // next link in list
	      
	      public Node(double dd) 
	      { 
	    	  dData = dd; 
	    	  next=null;
	      }


}
