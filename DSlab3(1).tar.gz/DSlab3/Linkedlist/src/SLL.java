
public class SLL {

	Node head;
	SLL()
	{
		head = null;
	}
	public boolean isempty()
	{
		if(head==null)
		{
			
			return true;
		}
		else
		{
			return false;
		}
	}
	
	public boolean islast(Node g)
	{
		if(g.next==null)
		{
			return true;
		}
		else
		{
			return false;
		}
	}
	
	public void sortedinsertion(int d)
	{
		Node current = head;
		Node n = new Node(d);
		while(current.dData<d)
		{
			current=current.next;
		}
		n.next=current.next;
		current.next=n;
	}
	
	public void insertAtfirst(int d)
	{
		Node n =new Node(d);
		if(head==null)
		{
			head=n;
			return;
		}
		n.next = head;
		head=n;
	}
	
	public void insertAtlast(int d)
	{
		
		Node current=head;
		Node last=new Node(d);
		if(head==null)
		{
			head=last;
			return;
		}
		while(current.next!=null)
		{
			current=current.next;
		}
		current.next=last;
		
	}
	
	public void insertAfter(Node g,int d)
	{
		Node n = new Node(d);
		n.next = g.next;
		g.next = n;
		
	}
	
	public void insertbefor(Node g,int d)
	{
		Node current=head;
		Node n=new Node(d);
		while(current.next!=g)
		{
			current=current.next;
		}
		n.next=current.next;
		current.next=n;
	}
	
	public void insertAtposi(int posi,int d)
	{
		Node current=head;
		Node temp=head;
		Node n=new Node(d);
		int j=1;
		while(temp.next!=null)
		{
			temp=temp.next;
			j++;
		}
		if(posi>j)
		{
			System.out.println("No position like this, but inserted at last");
			temp.next=n;
			return;
		}
		int i=1;
		while(posi!=i)
		{
			current=current.next;
			i++;
		}
		n.next=current.next;
		current.next=n;
	}
	
	public void deleteAtfront()
	{
		Node current = head.next;
		head.next=null;
		head = current;
	}
	
	public void deleteAtlast()
	{
		Node current = head;
		while(current.next.next!=null)
		{
			current=current.next;
		}
		current.next=null;
	}
	
	
	
	public void deleteAfter(Node g)
	{
		if(g.next==null)
		{
			System.out.println("No element next");
			return;
		}
		Node t= g.next.next;
		g.next.next=null;
		g.next=t;
	}
	
	public void deleteposi(int n)
	{
		Node current = head;
		int i=1;
		while(i+1!=n)
		{
			current=current.next;
			i++;
		}
		Node temp=current.next.next;
		current.next.next=null;
		current.next=temp;
	}
	
	public void deleteginode(Node g)
	{
		Node current=head;
		Node temp = g.next;
		while(current.next!=g)
		{
			current=current.next;
		}
		current.next=temp;
	}
	
	public void counteven()
	{
		Node current=head;
		int count=0;
		while(current!=null)
		{
			if(current.dData % 2==0)
			{
				count++;
			}
			current=current.next;
		}
		System.out.println("Even numbers count : "+count);
	}
	
	public void print()
	{
		if(head==null)
		{
			System.out.println("null");
			return;
		}
		Node current =head;
		while(current !=null)
		{
			System.out.println(current.dData);
			current=current.next;
		}
		
		
	}
}
