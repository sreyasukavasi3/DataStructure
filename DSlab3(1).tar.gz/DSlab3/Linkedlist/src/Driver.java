import java.util.*;
public class Driver {
	public static void main(String[] args)
	{
		Scanner s = new Scanner(System.in);
		SLL ob = new SLL();
		System.out.println("Enter the number of elements in the list : ");
		int n=s.nextInt();
		System.out.println("Enter the elements : ");
		for(int i=0;i<n;i++)
		{
			ob.insertAtlast(s.nextInt());
		}
		
		
		
		
		System.out.println("element is empty : "+ob.isempty());
		ob.print();
		s.close();
	}
}
