import java.util.Scanner;

public class maxofele {
	public static void main(String[] args) throws Exception{
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the size of array: ");
		int n = sc.nextInt();
		System.out.println("Enter the elements: ");
		int[] A = new int[n];
	
		for(int i=0; i<n; i++){
			 A[i]= sc.nextInt();
		}
		
		
		
		
		
		
			int max;
		
			max = A[0];
			for(int i=0; i<n; i++)
			{
			if(A[i]>max){
				max = A[i];
			}}
	    		
		 System.out.println( max); 
  
}
	} 







				 
		
	
