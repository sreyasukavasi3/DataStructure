import java.util.Scanner;
public class secoccurance {

	public static void main(String[] args) throws Exception{
		Scanner scanner = new Scanner(System.in);
				
		    System.out.println("Enter the size of the array:");
		    int a = scanner.nextInt();
		    System.out.println("Enter the array:");
			int[] ar = new int[a];
				
				for(int i=0; i<a; i++)
				{
				ar[i] = scanner.nextInt();
				}
				
				int key = 6;
				int count =0;
				for(int i=0;i<a;i++)
				{
				if(ar[i] == 6)
					count++;
				if(count == 2)
					{
					ar[i] = 7;
					break;
					}
				
				}
				System.out.println("Array:");
				
				
				for(int i=0; i<a; i++)
				{
					System.out.println(ar[i]);
				}
				
				
			
		}
		}