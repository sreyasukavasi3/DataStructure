package lab1;

import java.util.Scanner;

public class totMarks {
	
	public static void main(String[] args) {
		
		Scanner scanner = new Scanner(System.in);
		System.out.println("Enter the name: ");
		String varString = scanner.next();
		int sum=0;
		int perc=0;
		for(int i=1;i<=5; i++)
		{
			
			System.out.println("Enter the marks"+i);
			int varInt= scanner.nextInt();
			sum = sum + varInt;

		}
		perc = (sum*100)/500;
		System.out.println(sum); 	
		System.out.println(perc); 	
		}
}
