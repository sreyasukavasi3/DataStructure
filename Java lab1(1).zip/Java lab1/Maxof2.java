package lab1;

import java.util.Scanner;

public class Maxof2 {
	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		
		System.out.println("Enter the 2 no's : ");
		int varInt1= scanner.nextInt();
		int varInt2= scanner.nextInt();
		
		if(varInt1>varInt2) 
			System.out.println(varInt1 + " is max"); 

		else

			System.out.println(varInt2 + " is max"); 
	}

			


}
