package lab1;

import java.util.Scanner;

public class factorial {
	public static void main(String[] args) {
	int fact = 1;
	Scanner scanner = new Scanner(System.in);
	
	System.out.println("Enter the no : ");
	int varInt= scanner.nextInt();
	
	for(int i=varInt; i>=1; i--)
	{
		fact = fact*i;
	}
	System.out.println(fact); 

}
}
