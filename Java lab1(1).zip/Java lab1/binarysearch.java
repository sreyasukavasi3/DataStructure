import java.util.Scanner;
public class binarysearch {
	
     public static void main(String[] args) {
			

		Scanner scanner = new Scanner(System.in);
		
		System.out.println("Enter the size of the array:");
		int a = scanner.nextInt();
		
		
		int[] ar = new int[a];
		System.out.println("Enter the sorted array:");
		
		for(int i=0; i<a; i++)
		{
		ar[i] = scanner.nextInt();
		}
		
		System.out.println("Enter the element to be searched:");
		int key = scanner.nextInt();
		 
			int high = a-1; 
			int low = 0;
			int f = 0;
			
		for(int i=0;i<a-1;i++)
		{
			int mid = (low+high)/2;
			if(key == ar[mid])
				f = 1;
			
			else if(key > ar[mid])
			{
				low = mid+1;
				
			}
			
			else
			{
				high = mid-1;
			}
			
		}
		if(f==1)
			System.out.println("Element found");
		else
			System.out.println("Element not found");
			
}}