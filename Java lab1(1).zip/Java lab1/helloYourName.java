import java.util.Scanner;



public class helloYourName {
	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		
		System.out.println("Enter your name: ");
		String varString = scanner.next();
		  System.out.println("Hello "+ varString); 
		
	}

}
