import java.util.Scanner;
public class sort {
	public static void main(String[] args) throws Exception {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the size of array: ");
		int n = sc.nextInt();
		System.out.println("Enter the elements: ");
		int[] A = new int[n];
	
		for(int i=0; i<n; i++){
			 A[i]= sc.nextInt();
		}
		int temp;
        for(int i=0; i<n;i++) {
        	for(int j=i; j<n; j++) {
        		if(A[i]>A[j]) {
        			temp = A[j];
        			A[j] = A[i];
        			A[i] = temp;
         		}
        	}
        }
 
		for(int i=0; i<n; i++)
			System.out.println(A[i]);

}}

