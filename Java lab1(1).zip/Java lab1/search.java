import java.util.Scanner;
public class search {

	public static void main(String[] args) throws Exception{
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the size of array: ");
		int n = sc.nextInt();
		System.out.println("Enter the elements: ");
		int[] A = new int[n];
	
		for(int i=0; i<n; i++){
			 A[i]= sc.nextInt();
		}
		System.out.println("Enter the element to search: ");
		int ele = sc.nextInt();
		int f = 0;
		for(int i=0; i<n; i++){
			if(ele == A[i]){
				f++; 
			    break;}
				
			else
				f = 0;
		}
		if(f==0)
			System.out.println("Element NOT found");
		else
			System.out.println("Element found");
		
}}

