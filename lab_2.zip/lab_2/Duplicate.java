import java .util.*;
public class Duplicate {
	public static void main(String[] args){
		Scanner scan = new Scanner(System.in);
		System.out.println("enter no of elements in the array");
		int n = scan.nextInt();
		int a[] = new int[n];
		System.out.println("enter all elements in the array:");
		for(int i=0;i<n;i++){
			a[i]=scan.nextInt();
		}
		int k =0;
		int d[] = new int[n];
		for(int i=0;i<n-1;i++){
			if(a[i] != a[i+1]){
				d[k++] = a[i];
			}
			
		}
		d[k++] = a[n-1];
		System.out.println(" elements in the d array");
		
		
	     
		for(int i=0;i < k;i++){
			System.out.println(d[i]);
		}
		scan.close();
		System.out.println("no of elements in the d array" + k);
	
		
	}

}
