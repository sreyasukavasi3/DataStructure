import java.util.*;
public class Delete {
	public static void main(String[] args){
		Scanner scan = new Scanner(System.in);
		System.out.println("enter no of elements in the array");
		int n = scan.nextInt();
		int a[] = new int[n];
		System.out.println("enter all elements in the array:");
		for(int i=0;i<n;i++){
			a[i]=scan.nextInt();
		}
		System.out.println("enter the target number which you want to delete from the array");
		int s = scan.nextInt();
		int k =0;
		int d[] = new int[n];
		for(int i=0;i<n;i++){
			if(a[i]!= s){
				d[k++] = a[i];
			}
		}
		System.out.println(" elements in the d array");
	    for(int i=0;i < k;i++){
			System.out.println(d[i]);
		}
		scan.close();
		System.out.println("no of elements in the d array is " + " " + k);
	
	}

}
