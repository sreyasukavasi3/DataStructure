import java.util.*;
public class Split {
	public static void main (String[]args){
		Scanner scan = new Scanner(System.in);
		System.out.println("enter numbers of elemants in an array: ");
		int n = scan.nextInt();
		int a[] = new int[n];
		System.out.println("enter numbers of an array: ");
		for (int i=0;i<n;i++){
		
			a[i] = scan.nextInt();
			
			}
		for (int i=0;i<n;i++){
			System.out.println(a[i]);
		}
		System.out.println("enter an integer less than 6:");
		int j = scan.nextInt();
		for(int i=j;i<n;i++){
			System.out.println(a[i]);
			
		}
		scan.close();
		for(int i=0;i<j;i++){
			System.out.println(a[i]);
		}
		
	}

}
