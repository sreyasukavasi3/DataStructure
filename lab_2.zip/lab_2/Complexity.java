import java.util.*;
public class Complexity {
	public static void main(String[] args){
		Scanner scan = new Scanner(System.in);
		System.out.println("enter no of elements in the array");
		int n = scan.nextInt();
		int a[] = new int[n];
		System.out.println("enter all elements in the array in sorted manner:");
		for(int i=0;i<n;i++){
			a[i]=scan.nextInt();
		}
		int s= a[n/2];
		int count = 0;
		for(int i=0;i<n;i++){
			if(a[i] == s){
				count = count + 1;
			}
			
        }
		scan.close();
		System.out.println(s + " appears " + count + " times");
}
}
