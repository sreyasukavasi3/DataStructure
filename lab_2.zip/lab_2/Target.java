import java.util.*;
public class Target {
	public static void main(String[] args){
		Scanner scan = new Scanner(System.in);
		System.out.println("enter no.of elements in the array");
		 int n= scan.nextInt();
		int a[] = new int[n];
		for(int i=0;i<n;i++){
			a[i]= scan.nextInt();
		}
		System.out.println("enter the target sum");
		int s = scan.nextInt();
		for(int i=0;i<n-1;i++){
			for(int j = i+1;j<n;j++ ){
				if((a[i]+a[j]) == s){
					System.out.println( i + "," + j);
				}
			}
		}
		scan.close();
		
	}

}
