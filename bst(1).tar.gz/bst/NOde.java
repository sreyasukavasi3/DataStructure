package bst;
public class NOde {
	int data;
	NOde left;
	NOde right;
	NOde(int d)
	{
		data=d;
		left=null;
		right=null;
	}

}