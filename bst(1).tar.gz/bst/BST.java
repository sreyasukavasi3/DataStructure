package bst;

import java.util.Iterator;

public class BST {
 NOde root;
 BST()
 {
	 root=null;
 }
 int FindminBST(NOde r)
 {
	 if(r==null)
		 return -1;
	 else if (r.left==null) 
	 {
		 return r.data;
	 }
		 else
     {
		return FindminBST(r.left);
	 }
 }
 int FindmaxBST(NOde r)
 {
	 if(r==null)
		 return -1;
	 else if (r.right==null) 
	 {
		 return r.data;
	 }
	else
     {
		return FindmaxBST(r.right);
	 }
 }
 void inorder(NOde r)
 {
	 if(r==null)
		 return;
	 inorder(r.left);
	 System.out.print(r.data+" ");
	 inorder(r.right);
 }
 void preorder(NOde r)
 {
	 if(r==null)
		 return;
	 System.out.print(r.data+" ");
	 preorder(r.left);
	 preorder(r.right);
 }
 
 void postorder(NOde r)
 {
	 if(r==null)
		 return;
	 
	 postorder(r.left);
	 postorder(r.right);
	 System.out.print(r.data+" ");
 }
 
 NOde insertBST(NOde r,int d)
 {
	 if(r==null)
	 {
		 NOde n=new NOde(d);
		 r=n;
		 return r;
				 
	 }
	 if(r.data<d) {
		 r.right=insertBST(r.right,d);
	 }
	 else if(r.data>d)
	 {
		 r.left=insertBST(r.left,d);
	 }

		 return r;

 }
 NOde deleteBST(NOde r,int d)
 {
	 if(r==null)
	 {
		 return r;
	 }
	 if(r.data>d)
		 r.left=deleteBST(r.left,d);
	 else if(r.data<d)
	 {
		 r.right=deleteBST(r.right,d);
	 }
	 else
	 {
		 if(r.left==null && r.right ==null)
			 return null;
		 else if(r.left==null)
			 return r.right;
		 else if(r.right==null)
			 return (r.left);
		 else
		 {
			 NOde insuc=new NOde(FindminBST(r.right));
			 r.data =insuc.data;
			 r.right=deleteBST(r.right,r.data);
		 }
		 
		 
	 }
	 return r;
 }
 boolean search(NOde r,int d)
 {
	 if(r==null)
		 return false;
	 if(r.data==d)
		 return true;
	 else
	 {
		 if(d>r.data)
		 {
			 return search(r.right,d);
		 }
		 if(d<r.data)
		 {
			 return search(r.left,d);
		 }
		 return true;
	 }
 }

 int height(NOde r)
 {
	 if(r==null)
		 return 0;
	int right=1+height(r.right);
	int left=1+height(r.left);
	if(left>right)
	{
		return left;
	}
	else
		return right;
 }
 void kthLargestUtil(NOde node, int k, int c) 
    { 
        if (node == null || c >= k) 
            return; 
          

        this.kthLargestUtil(node.right, k, c);  
        c++; 
          
        if (c == k) { 
            System.out.println(k + "th largest element is " +  
                                                 node.data); 
            return; 
        } 
          

        this.kthLargestUtil(node.left, k, c);  
    } 
    void kthLargest(int k) 
    { 
        int c = 0;  
        this.kthLargestUtil(this.root, k, c); 
    } 

    public static void convertToBST(NOde root, Iterator<Integer> it)
	{
		if (root == null) {
			return;
		}

		convertToBST(root.left, it);
		root.data = it.next();
		convertToBST(root.right, it);
	}

 }