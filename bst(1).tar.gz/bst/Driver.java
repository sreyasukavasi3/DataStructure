
package bst;
public class Driver {
	public static void main(String[] args)
	{
		//30, 35, 40,50,12,17,45,90,23,56
		BST b= new BST();
		b.root=b.insertBST(b.root,30);
		b.root=b.insertBST(b.root,35);
		b.root=b.insertBST(b.root,40);
		b.root=b.insertBST(b.root,50);
		b.root=b.insertBST(b.root,12);
		b.root=b.insertBST(b.root,17);
		b.root=b.insertBST(b.root,45);
		b.root=b.insertBST(b.root,90);
		b.root=b.insertBST(b.root,23);
		b.root=b.insertBST(b.root,56);
		b.inorder(b.root);
		System.out.println("");
		b.root=b.deleteBST(b.root, 17);

		b.inorder(b.root);
		System.out.println("");
		b.preorder(b.root);
		System.out.println("");
		b.postorder(b.root);
		System.out.println("");
		// 40, 90, 32, 92, 56
		System.out.println(b.search(b.root,40));
		System.out.println(b.search(b.root,90));
		System.out.println(b.search(b.root,32));
		System.out.println(b.search(b.root,92));
		System.out.println(b.search(b.root,56));
		System.out.println("Max is"+b.FindmaxBST(b.root));
		System.out.println("Min is"+b.FindminBST(b.root));
		System.out.println(b.height(b.root));
		b.kthLargestUtil(b.root, 5,0);
	}
}